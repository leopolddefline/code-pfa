import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "pages/Home";
import NotFound from "pages/NotFound";
const IPhone14ProSixty = React.lazy(() => import("pages/IPhone14ProSixty"));
const IPhone14ProFiftyNine = React.lazy(() =>
  import("pages/IPhone14ProFiftyNine")
);
const IPhone14ProFiftyEight = React.lazy(() =>
  import("pages/IPhone14ProFiftyEight")
);
const IPhone14ProFiftySeven = React.lazy(() =>
  import("pages/IPhone14ProFiftySeven")
);
const IPhone14ProFiftySix = React.lazy(() =>
  import("pages/IPhone14ProFiftySix")
);
const IPhone14ProFiftyFive = React.lazy(() =>
  import("pages/IPhone14ProFiftyFive")
);
const IPhone14ProFiftyFour = React.lazy(() =>
  import("pages/IPhone14ProFiftyFour")
);
const ProjectRoutes = () => {
  return (
    <React.Suspense fallback={<>Loading...</>}>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="*" element={<NotFound />} />
          <Route
            path="/iphone14profiftyfour"
            element={<IPhone14ProFiftyFour />}
          />
          <Route
            path="/iphone14profiftyfive"
            element={<IPhone14ProFiftyFive />}
          />
          <Route
            path="/iphone14profiftysix"
            element={<IPhone14ProFiftySix />}
          />
          <Route
            path="/iphone14profiftyseven"
            element={<IPhone14ProFiftySeven />}
          />
          <Route
            path="/iphone14profiftyeight"
            element={<IPhone14ProFiftyEight />}
          />
          <Route
            path="/iphone14profiftynine"
            element={<IPhone14ProFiftyNine />}
          />
          <Route path="/iphone14prosixty" element={<IPhone14ProSixty />} />
        </Routes>
      </Router>
    </React.Suspense>
  );
};
export default ProjectRoutes;
