import React from "react";

const variantClasses = {
  h1: "font-black sm:text-4xl md:text-[38px] text-[40px]",
  h2: "font-bold sm:text-3xl md:text-[32px] text-[34px]",
  h3: "font-black sm:text-[29px] md:text-[31px] text-[33px]",
  h4: "font-bold text-2xl md:text-[22px] sm:text-xl",
  h5: "font-bold sm:text-[17px] md:text-[19px] text-[21px]",
  h6: "font-normal sm:text-[16.46px] md:text-[18.46px] text-[20.46px]",
  body1: "text-xl",
  body2: "font-normal text-[19px]",
  body3: "font-bold text-[18.73px]",
  body4: "font-bold text-lg",
  body5: "text-[17px]",
  body6: "text-base",
  body7: "font-light text-[15px]",
  body8: "font-normal text-[14.98px]",
  body9: "text-sm",
  body10: "font-bold text-[13.89px]",
  body11: "font-normal text-[13px]",
  body12: "text-xs",
  body13: "text-[11.08px]",
  body14: "text-[11.03px]",
  body15: "font-bold text-[10px]",
};

const Text = ({ children, className = "", variant, as, ...restProps }) => {
  const Component = as || "span";
  return (
    <Component
      className={`${className} ${variant && variantClasses[variant]}`}
      {...restProps}
    >
      {children}
    </Component>
  );
};

export { Text };
