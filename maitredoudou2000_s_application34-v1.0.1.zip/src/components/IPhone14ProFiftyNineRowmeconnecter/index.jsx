import React from "react";

import { Img, Text } from "components";

const IPhone14ProFiftyNineRowmeconnecter = (props) => {
  return (
    <>
      <div className={props.className}>
        <Text
          className="font-bold font-myriadpro text-red_A400 w-auto"
          variant="body1"
        >
          {props?.meconnecter}
        </Text>
        <Img
          src="images/img_frame625954.svg"
          className="h-[38px]"
          alt="frame625954"
        />
      </div>
    </>
  );
};

IPhone14ProFiftyNineRowmeconnecter.defaultProps = { meconnecter: "Rechercher" };

export default IPhone14ProFiftyNineRowmeconnecter;
