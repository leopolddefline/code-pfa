import React from "react";

import { Img, Text } from "components";

const IPhone14ProFiftySixColumnFive = (props) => {
  return (
    <>
      <div className={props.className}>
        <div className="flex flex-row gap-[27px] items-center justify-center mb-1 w-auto">
          <div className="flex flex-col gap-[5px] items-center justify-center w-11">
            <Img
              src="images/img_icoutlinecont.svg"
              className="h-6 w-[26px]"
              alt="icoutlinecont"
            />
            <Text
              className="font-myriadpro font-normal text-center text-gray_600 w-auto"
              variant="body12"
            >
              {props?.location}
            </Text>
          </div>
          <div className="flex flex-col gap-[5px] h-[53px] md:h-auto items-center justify-center w-auto">
            <Img
              src="images/img_vector.svg"
              className="h-6 w-[26px]"
              alt="vector"
            />
            <Text
              className="font-myriadpro font-normal text-center text-gray_600 w-auto"
              variant="body12"
            >
              {props?.chantier}
            </Text>
          </div>
          <Img
            src="images/img_image13.png"
            className="h-[76px] md:h-auto object-cover w-[77px]"
            alt="imageThirteen"
          />
          <div className="flex flex-col items-center justify-start w-[14%]">
            <div className="flex flex-col gap-px items-center justify-center w-auto">
              <Img
                src="images/img_file_gray_600.svg"
                className="h-[33px] w-[33px]"
                alt="file_Three"
              />
              <Text
                className="font-myriadpro font-normal text-center text-gray_600"
                variant="body12"
              >
                {props?.facturedevis}
              </Text>
            </div>
          </div>
          <div className="flex flex-col gap-[5px] h-[43px] md:h-auto items-center justify-center w-auto">
            <Img
              src="images/img_user.svg"
              className="h-6 w-[19px]"
              alt="user"
            />
            <Text
              className="font-myriadpro font-normal text-gray_600 w-auto"
              variant="body12"
            >
              {props?.compte}
            </Text>
          </div>
        </div>
      </div>
    </>
  );
};

IPhone14ProFiftySixColumnFive.defaultProps = {
  location: "Location",
  chantier: "Chantier",
  facturedevis: (
    <>
      Facture &<br />
      Devis
    </>
  ),
  compte: "Compte",
};

export default IPhone14ProFiftySixColumnFive;
