import React from "react";
import PropTypes from "prop-types";

const shapes = {
  CircleBorder19: "rounded-[19px]",
  RoundedBorder5: "rounded-[5px]",
};
const variants = {
  OutlineRedA700_1:
    "bg-white_A700 border border-red_A700 border-solid text-red_A700",
  FillRedA700: "bg-red_A700 text-white_A700",
  OutlineRedA400:
    "bg-white_A700 border-[3px] border-red_A400 border-solid text-red_A400",
  OutlineRedA700:
    "bg-white_A700 border-2 border-red_A700 border-solid text-red_A700",
  FillGray40001: "bg-gray_400_01 text-black_900",
};
const sizes = { sm: "p-1.5", md: "p-2.5", lg: "p-3.5" };

const Button = ({
  children,
  className = "",
  leftIcon,
  rightIcon,
  shape,
  variant,
  size,
  ...restProps
}) => {
  return (
    <button
      className={`${className} ${(shape && shapes[shape]) || ""} ${
        (size && sizes[size]) || ""
      } ${(variant && variants[variant]) || ""}`}
      {...restProps}
    >
      {!!leftIcon && leftIcon}
      {children}
      {!!rightIcon && rightIcon}
    </button>
  );
};

Button.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  shape: PropTypes.oneOf(["CircleBorder19", "RoundedBorder5"]),
  variant: PropTypes.oneOf([
    "OutlineRedA700_1",
    "FillRedA700",
    "OutlineRedA400",
    "OutlineRedA700",
    "FillGray40001",
  ]),
  size: PropTypes.oneOf(["sm", "md", "lg"]),
};

Button.defaultProps = { className: "", shape: "", variant: "", size: "" };
export { Button };
