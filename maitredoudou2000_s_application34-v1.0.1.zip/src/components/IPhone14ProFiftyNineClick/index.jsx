import React from "react";

const IPhone14ProFiftyNineClick = (props) => {
  return (
    <>
      <div className={props.className}>
        <div className="border border-red_400 border-solid h-2.5 rounded-[50%] w-2.5"></div>
      </div>
    </>
  );
};

IPhone14ProFiftyNineClick.defaultProps = {};

export default IPhone14ProFiftyNineClick;
