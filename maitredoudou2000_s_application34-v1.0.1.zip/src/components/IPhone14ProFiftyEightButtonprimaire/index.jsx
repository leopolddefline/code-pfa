import React from "react";

import { Text } from "components";

const IPhone14ProFiftyEightButtonprimaire = (props) => {
  return (
    <>
      <Text className={props.className} variant="body4">
        {props?.buttonprimaire}
      </Text>
    </>
  );
};

IPhone14ProFiftyEightButtonprimaire.defaultProps = {};

export default IPhone14ProFiftyEightButtonprimaire;
