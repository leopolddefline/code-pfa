import React from "react";

import { Img, Text } from "components";

const IPhone14ProFiftyFourTabbar = (props) => {
  return (
    <>
      <div className={props.className}>
        <div className="flex flex-col h-10 md:h-auto items-start justify-start sm:px-5 px-[26px] w-full">
          <div className="bg-white_A700 flex flex-row items-center justify-start p-[9px] rounded-[10px] shadow-bs2 w-full">
            <Img
              src="images/img_sfsymboltextformatsize.svg"
              className="h-3 ml-[3px]"
              alt="sfsymboltextfor"
            />
            <div className="flex flex-row gap-1.5 items-center justify-start ml-[91px] w-auto">
              <Img
                src="images/img_lock.svg"
                className="h-[11px] w-[7px]"
                alt="lock"
              />
              <Text
                className="font-normal font-sfprotext text-black_900 tracking-[-0.41px] w-auto"
                variant="body5"
              >
                {props?.weburl}
              </Text>
            </div>
            <Img
              src="images/img_refresh.svg"
              className="h-[18px] ml-[50px]"
              alt="refresh"
            />
          </div>
        </div>
        <Img src="images/img_tabs.svg" className="h-[49px] w-full" alt="tabs" />
      </div>
    </>
  );
};

IPhone14ProFiftyFourTabbar.defaultProps = { weburl: "myloxam.fr/login" };

export default IPhone14ProFiftyFourTabbar;
