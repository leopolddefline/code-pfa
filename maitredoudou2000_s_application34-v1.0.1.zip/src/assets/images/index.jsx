import { CloseSVG } from "./close";
import { SearchSVG } from "./search";
export { CloseSVG, SearchSVG };
