import React from "react";

import { Button, Img, Line, Text } from "components";
import IPhone14ProFiftyNineClick from "components/IPhone14ProFiftyNineClick";
import IPhone14ProFiftyNineRowmeconnecter from "components/IPhone14ProFiftyNineRowmeconnecter";

const IPhone14ProFiftyNinePage = () => {
  return (
    <>
      <div className="bg-white_A700 flex flex-col items-center justify-start mx-auto pb-[562px] md:pr-10 sm:pr-5 pr-[562px] shadow-bs6 w-full">
        <div className="flex flex-row font-sfprotext items-start justify-start p-[11px] w-[90%] md:w-full">
          <Text
            className="font-semibold ml-[21px] mt-1 text-black_900 text-center tracking-[-0.28px]"
            variant="body9"
          >
            9:41
          </Text>
          <Img
            src="images/img_signal.svg"
            className="h-2.5 ml-[249px] mt-1.5"
            alt="signal"
          />
          <Img
            src="images/img_signal_black_900.svg"
            className="h-2.5 ml-[5px] mt-[5px]"
            alt="signal_One"
          />
          <Img
            src="images/img_videocamera.svg"
            className="h-[11px] ml-[5px] mt-[5px]"
            alt="videocamera"
          />
        </div>
        <div className="font-myriadpro h-[145px] relative w-full">
          <Text
            className="absolute bottom-[5%] right-[0] text-center text-white_A700"
            as="h1"
            variant="h1"
          >
            MyLoxam
          </Text>
          <div className="absolute flex flex-col h-full inset-y-[0] items-center justify-start left-[0] my-auto w-[90%]">
            <div className="h-[72px] relative w-full">
              <div className="bg-white_A700 h-[72px] my-auto w-[42%]"></div>
              <div className="absolute bg-gray_50 flex flex-col h-full inset-[0] items-center justify-center m-auto p-[11px] rounded-[10px] shadow-bs5 w-full">
                <div className="flex flex-row gap-2 items-start justify-center mt-[5px] w-[54%] md:w-full">
                  <Img
                    src="images/img_1280pxloxamlogo.png"
                    className="h-[35px] md:h-auto object-cover w-[21%]"
                    alt="1280pxloxamlogo"
                  />
                  <Text className="mt-0.5 text-red_A700" as="h2" variant="h2">
                    MyLoxam
                  </Text>
                </div>
              </div>
            </div>
            <div className="bg-gray_50 flex flex-row items-center justify-between pl-[19px] py-[19px] rounded-[10px] shadow-bs5 w-full">
              <Img
                src="images/img_menu.svg"
                className="h-[17px] ml-1.5"
                alt="menu"
              />
              <div className="border border-black_900 border-solid flex flex-col items-end justify-start p-1.5 rounded-[3px]">
                <Img
                  src="images/img_search.svg"
                  className="h-[19px] mr-2 w-[19px]"
                  alt="search"
                />
              </div>
              <Img
                src="images/img_cart.svg"
                className="h-[25px] w-6"
                alt="cart"
              />
            </div>
          </div>
        </div>
        <Text
          className="font-myriadpro leading-[20.00px] mt-[9px] text-black_900 w-[83%] sm:w-full"
          variant="body11"
        >
          Accueil / Elévation et Travail en hauteur /Plate forme élévatrice /
          Nacelle ciseau / Nacelle électrique / Panier
        </Text>
        <div className="font-myriadpro h-11 md:h-[41px] mt-0.5 relative w-[83%]">
          <Line className="absolute bg-red_A700 bottom-[34%] h-[3px] inset-x-[0] mx-auto w-full" />
          <div className="absolute bottom-[0] flex flex-row items-center justify-start left-[5%] w-[63%]">
            <Button
              className="cursor-pointer font-normal h-[38px] leading-[normal] rounded-[50%] sm:text-[16.46px] md:text-[18.46px] text-[20.46px] text-center text-red_A700 w-[38px]"
              size="sm"
              variant="OutlineRedA700_1"
            >
              01
            </Button>
            <Button
              className="cursor-pointer font-bold h-[38px] leading-[normal] ml-[34px] rounded-[50%] sm:text-[16.46px] md:text-[18.46px] text-[20.46px] text-center text-red_A700 w-[38px]"
              size="sm"
              variant="OutlineRedA700"
            >
              02
            </Button>
            <Button
              className="cursor-pointer font-normal h-[38px] leading-[normal] ml-[77px] rounded-[50%] sm:text-[16.46px] md:text-[18.46px] text-[20.46px] text-center text-red_A700 w-[38px]"
              size="sm"
              variant="OutlineRedA700_1"
            >
              03
            </Button>
          </div>
          <Button
            className="absolute cursor-pointer font-normal h-[38px] leading-[normal] right-[0] rounded-[50%] sm:text-[16.46px] md:text-[18.46px] text-[20.46px] text-center text-red_A700 top-[0] w-[38px]"
            size="sm"
            variant="OutlineRedA700_1"
          >
            04
          </Button>
        </div>
        <Text
          className="font-myriadpro mt-2.5 text-black_900 w-[74%] sm:w-full"
          as="h4"
          variant="h4"
        >
          Choisissez votre mode de retrait :
        </Text>
        <div className="font-myriadpro md:h-[102px] h-[147px] mt-[22px] relative w-[83%]">
          <div className="absolute bg-white_A700 bottom-[0] flex flex-col items-center justify-end left-[0] p-3 rounded shadow-bs4 w-[89%]">
            <IPhone14ProFiftyNineRowmeconnecter
              className="bg-white_A700 border-[3px] border-red_A400 border-solid flex flex-row gap-2 h-14 md:h-auto items-center justify-center md:px-10 sm:px-5 px-[66px] py-4 rounded-[7px] w-[203px] sm:w-full"
              meconnecter="Rechercher"
            />
          </div>
          <div className="absolute bg-white_A700 flex flex-col inset-x-[0] items-start justify-start mx-auto p-3 rounded shadow-bs4 top-[0] w-full">
            <div className="flex flex-row gap-2.5 items-center justify-start w-[95%] md:w-full">
              <div className="bg-white_A700 flex flex-col h-[21px] items-center justify-end my-[11px] p-[5px] rounded-[10px] shadow-bs4 w-[21px]">
                <div className="bg-red_400 border border-red_400 border-solid h-2.5 rounded-[50%] w-2.5"></div>
              </div>
              <div className="flex flex-col items-start justify-start w-[91%]">
                <Text className="text-black_900" variant="body3">
                  Click & collect en agence Loxam
                </Text>
                <Line className="bg-black_900_7f h-px mt-0.5 w-full" />
                <Text className="text-gray_600_01" variant="body8">
                  Gratuit
                </Text>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-white_A700 flex flex-col font-myriadpro items-center justify-start mb-[21px] mt-[27px] p-[9px] md:px-5 rounded shadow-bs4 w-[83%] md:w-full">
          <div className="flex flex-row gap-[15px] items-center justify-between mb-[5px] w-[95%] md:w-full">
            <IPhone14ProFiftyNineClick className="bg-white_A700 flex flex-col h-[21px] items-center justify-end mb-[9px] mt-[15px] p-[5px] rounded-[10px] shadow-bs4 w-[21px] sm:w-full" />
            <div className="flex flex-col items-start justify-start w-[89%]">
              <Text className="text-black_900" variant="body3">
                Livraison
              </Text>
              <Line className="bg-black_900_7f h-px mt-1 w-full" />
              <Text className="text-gray_600_01" variant="body8">
                250 €
              </Text>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default IPhone14ProFiftyNinePage;
