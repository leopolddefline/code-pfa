import React from "react";

import { Button, Img, Text } from "components";
import IPhone14ProFiftySixColumnFive from "components/IPhone14ProFiftySixColumnFive";

const IPhone14ProFiftySixPage = () => {
  return (
    <>
      <div className="bg-white_A700 flex flex-col font-sfprotext items-start justify-start mx-auto shadow-bs6 w-full">
        <div className="flex flex-row items-start justify-start p-[11px] md:px-5 w-2/5 md:w-full">
          <Text
            className="font-semibold ml-[21px] mt-1 text-black_900 text-center tracking-[-0.28px]"
            variant="body9"
          >
            9:41
          </Text>
          <Img
            src="images/img_signal.svg"
            className="h-2.5 ml-[249px] mt-1.5"
            alt="signal"
          />
          <Img
            src="images/img_signal_black_900.svg"
            className="h-2.5 ml-[5px] mt-[5px]"
            alt="signal_One"
          />
          <Img
            src="images/img_videocamera.svg"
            className="h-[11px] ml-[5px] mt-[5px]"
            alt="videocamera"
          />
        </div>
        <div className="font-myriadpro h-[1079px] sm:h-[1411px] md:h-[709px] md:px-5 relative w-[48%] sm:w-full">
          <div className="absolute flex flex-col md:gap-10 gap-[155px] inset-x-[0] justify-start mx-auto top-[0] w-full">
            <div className="md:h-[142px] h-[143px] relative w-[93%] sm:w-full">
              <Text
                className="absolute bottom-[4%] right-[0] text-center text-white_A700"
                as="h1"
                variant="h1"
              >
                MyLoxam
              </Text>
              <div className="absolute flex flex-col h-full inset-y-[0] items-center justify-start left-[0] my-auto w-[90%]">
                <div className="bg-gray_50 flex flex-col items-center justify-end p-[11px] rounded-[10px] shadow-bs5 w-full">
                  <div className="flex flex-row gap-2 items-start justify-center mt-[5px] w-[54%] md:w-full">
                    <Img
                      src="images/img_1280pxloxamlogo.png"
                      className="h-[35px] md:h-auto object-cover w-[21%]"
                      alt="1280pxloxamlogo"
                    />
                    <Text className="mt-0.5 text-red_A700" as="h2" variant="h2">
                      MyLoxam
                    </Text>
                  </div>
                </div>
                <div className="bg-gray_50 flex flex-row items-start justify-end p-3.5 rounded-[10px] shadow-bs5 w-full">
                  <Img
                    src="images/img_menu.svg"
                    className="h-[17px] mt-3"
                    alt="menu"
                  />
                  <div className="border border-black_900 border-solid h-[34px] ml-[13px] mt-[9px] rounded-[3px] w-[41%]"></div>
                  <Img
                    src="images/img_cart.svg"
                    className="h-[26px] mt-3 mx-9"
                    alt="cart"
                  />
                </div>
              </div>
            </div>
            <div className="flex flex-col items-center justify-start md:ml-[0] ml-[29px] w-[94%] md:w-full">
              <div className="gap-2.5 sm:gap-5 grid sm:grid-cols-1 grid-cols-2 justify-center min-h-[auto] w-full">
                <div className="flex flex-1 flex-row gap-[9px] items-start justify-between w-full">
                  <div className="h-[167px] relative w-[73%]">
                    <Img
                      src="images/img_rectangle363.png"
                      className="h-[111px] mb-[-28px] mx-auto object-cover rounded-[5px] w-full z-[1]"
                      alt="rectangle363"
                    />
                    <div className="bg-red_A700 flex flex-col items-center justify-end mt-auto mx-auto pt-7 rounded-[5px] w-full">
                      <Text
                        className="font-bold text-center text-white_A700"
                        variant="body12"
                      >
                        <>
                          Nacelle éléctrique 6m
                          <br />
                          louée du 26mai au 12juin
                        </>
                      </Text>
                    </div>
                  </div>
                  <div className="flex flex-row items-start justify-evenly w-[24%]">
                    <Text
                      className="text-center text-light_green_A700"
                      variant="body15"
                    >
                      En cours
                    </Text>
                    <div className="bg-light_green_A700 h-2 rounded-[50%] w-2"></div>
                  </div>
                </div>
                <div className="flex flex-1 flex-row items-start justify-center w-full">
                  <div className="h-[168px] mt-[3px] relative w-3/4">
                    <Img
                      src="images/img_rectangle363.png"
                      className="h-[111px] mb-[-28px] mx-auto object-cover rounded-[5px] w-full z-[1]"
                      alt="rectangle363"
                    />
                    <div className="bg-red_A700 flex flex-col items-center justify-end mt-auto mx-auto pt-7 rounded-[5px] w-full">
                      <Text
                        className="font-bold text-center text-white_A700"
                        variant="body12"
                      >
                        <>
                          Nacelle éléctrique 6m
                          <br />
                          louée du 26mai au 12juin
                        </>
                      </Text>
                    </div>
                  </div>
                  <div className="flex flex-row items-start justify-evenly ml-[3px] w-[24%]">
                    <Text
                      className="text-center text-light_green_A700"
                      variant="body15"
                    >
                      En cours
                    </Text>
                    <div className="bg-light_green_A700 h-2 rounded-[50%] w-2"></div>
                  </div>
                </div>
                <div className="flex flex-1 flex-row gap-[9px] items-start justify-between w-full">
                  <div className="h-[168px] relative w-[73%]">
                    <Img
                      src="images/img_rectangle363.png"
                      className="h-[111px] mb-[-28px] mx-auto object-cover rounded-[5px] w-full z-[1]"
                      alt="rectangle363"
                    />
                    <div className="bg-red_A700 flex flex-col items-center justify-end mt-auto mx-auto pt-7 rounded-[5px] w-full">
                      <Text
                        className="font-bold text-center text-white_A700"
                        variant="body12"
                      >
                        <>
                          Nacelle éléctrique 6m
                          <br />
                          louée du 26mai au 12juin
                        </>
                      </Text>
                    </div>
                  </div>
                  <div className="flex flex-row items-start justify-evenly w-[24%]">
                    <Text
                      className="text-center text-light_green_A700"
                      variant="body15"
                    >
                      En cours
                    </Text>
                    <div className="bg-light_green_A700 h-2 rounded-[50%] w-2"></div>
                  </div>
                </div>
                <div className="flex flex-1 flex-row gap-2.5 items-start justify-between w-full">
                  <div className="h-[168px] relative w-[73%]">
                    <Img
                      src="images/img_rectangle363.png"
                      className="h-[111px] mb-[-28px] mx-auto object-cover rounded-[5px] w-full z-[1]"
                      alt="rectangle363"
                    />
                    <div className="bg-red_A700 flex flex-col items-center justify-end mt-auto mx-auto pt-7 rounded-[5px] w-full">
                      <Text
                        className="font-bold text-center text-white_A700"
                        variant="body12"
                      >
                        <>
                          Nacelle éléctrique 6m
                          <br />
                          louée du 26mai au 12juin
                        </>
                      </Text>
                    </div>
                  </div>
                  <div className="flex flex-row items-start justify-evenly w-[24%]">
                    <Text
                      className="text-center text-light_green_A700"
                      variant="body15"
                    >
                      En cours
                    </Text>
                    <div className="bg-light_green_A700 h-2 rounded-[50%] w-2"></div>
                  </div>
                </div>
                <div className="flex flex-1 flex-row gap-[9px] items-start justify-between w-full">
                  <div className="h-[168px] mt-1.5 relative w-[73%]">
                    <Img
                      src="images/img_rectangle363.png"
                      className="h-[111px] mb-[-28px] mx-auto object-cover rounded-[5px] w-full z-[1]"
                      alt="rectangle363"
                    />
                    <div className="bg-red_A700 flex flex-col items-center justify-end mt-auto mx-auto pt-7 rounded-[5px] w-full">
                      <Text
                        className="font-bold text-center text-white_A700"
                        variant="body12"
                      >
                        <>
                          Nacelle éléctrique 6m
                          <br />
                          louée du 26mai au 12juin
                        </>
                      </Text>
                    </div>
                  </div>
                  <div className="flex flex-row items-start justify-evenly w-[24%]">
                    <Text
                      className="text-center text-light_green_A700"
                      variant="body15"
                    >
                      En cours
                    </Text>
                    <div className="bg-light_green_A700 h-2 rounded-[50%] w-2"></div>
                  </div>
                </div>
                <div className="flex flex-1 flex-row gap-4 items-start justify-between w-full">
                  <div className="h-[168px] relative w-[71%]">
                    <Img
                      src="images/img_rectangle363.png"
                      className="h-[111px] mb-[-28px] mx-auto object-cover rounded-[5px] w-full z-[1]"
                      alt="rectangle363"
                    />
                    <div className="bg-red_A700 flex flex-col items-center justify-end mt-auto mx-auto pt-7 rounded-[5px] w-full">
                      <Text
                        className="font-bold text-center text-white_A700"
                        variant="body12"
                      >
                        <>
                          Nacelle éléctrique 6m
                          <br />
                          louée du 26mai au 12juin
                        </>
                      </Text>
                    </div>
                  </div>
                  <div className="flex flex-row items-start justify-evenly w-[23%]">
                    <Text
                      className="text-center text-light_green_A700"
                      variant="body15"
                    >
                      En cours
                    </Text>
                    <div className="bg-light_green_A700 h-2 rounded-[50%] w-2"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute flex flex-col gap-[27px] justify-start left-[4%] top-[15%] w-[74%]">
            <Button
              className="cursor-pointer font-bold leading-[normal] text-center text-red_A400 text-xl w-[351px]"
              shape="RoundedBorder5"
              size="lg"
              variant="OutlineRedA400"
            >
              Réserver une machine
            </Button>
            <Text
              className="md:ml-[0] ml-[7px] text-red_A700"
              as="h4"
              variant="h4"
            >
              Mes machines
            </Text>
          </div>
          <Button
            className="absolute bottom-[14%] cursor-pointer font-bold leading-[normal] left-[23%] min-w-[213px] text-center text-lg text-white_A700"
            shape="RoundedBorder5"
            size="lg"
            variant="FillRedA700"
          >
            Voir plus
          </Button>
          <div className="absolute flex flex-col h-max inset-y-[0] items-center justify-start left-[4%] my-auto w-[76%]">
            <div className="flex flex-col md:gap-10 gap-[918px] justify-start w-full">
              <Img
                src="images/img_iconamoonnotification.svg"
                className="h-6 md:ml-[0] ml-[298px] w-6"
                alt="iconamoonnotifi"
              />
              <div className="flex flex-col gap-[9px] items-start justify-start w-full">
                <Text
                  className="ml-0.5 md:ml-[0] text-red_A700"
                  as="h5"
                  variant="h5"
                >
                  Mes Documents
                </Text>
                <div className="flex flex-row gap-5 items-center justify-between w-full">
                  <div className="bg-red_A700 flex flex-col items-center justify-end p-[13px] rounded-[7px] w-[30%]">
                    <div className="flex flex-col gap-2.5 items-center justify-center w-auto">
                      <Img
                        src="images/img_file.svg"
                        className="h-9 w-9"
                        alt="file"
                      />
                      <div className="flex flex-col items-center justify-start w-full">
                        <Text className="text-white_A700" variant="body10">
                          Devis
                        </Text>
                      </div>
                    </div>
                  </div>
                  <div className="bg-gray_400 flex flex-col items-center justify-end p-2 rounded-[7px] w-[30%]">
                    <div className="flex flex-col gap-2.5 items-center justify-center w-[47px]">
                      <Img
                        src="images/img_file.svg"
                        className="h-9 w-9"
                        alt="file_One"
                      />
                      <div className="flex flex-col items-center justify-start pb-[11px] w-full">
                        <Text className="text-white_A700" variant="body10">
                          Contrat
                        </Text>
                      </div>
                    </div>
                  </div>
                  <div className="bg-red_A700 flex flex-col items-center justify-end p-[13px] rounded-[7px] w-[30%]">
                    <div className="flex flex-col gap-2.5 items-center justify-center w-auto">
                      <Img
                        src="images/img_file.svg"
                        className="h-9 w-9"
                        alt="file_Two"
                      />
                      <div className="flex flex-col items-center justify-start w-full">
                        <Text className="text-white_A700" variant="body10">
                          Réservation
                        </Text>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <IPhone14ProFiftySixColumnFive
          className="bg-gray_100 flex flex-col font-myriadpro items-center justify-start mt-[138px] md:px-5 rounded-[5px] shadow-bs3 sm:w-full"
          location="Location"
          chantier="Chantier"
          facturedevis={
            <>
              Facture &<br />
              Devis
            </>
          }
          compte="Compte"
        />
      </div>
    </>
  );
};

export default IPhone14ProFiftySixPage;
