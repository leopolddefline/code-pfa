import React from "react";

import { Button, Img, Line, List, Text } from "components";
import IPhone14ProFiftyEightButtonprimaire from "components/IPhone14ProFiftyEightButtonprimaire";

const IPhone14ProFiftyEightPage = () => {
  return (
    <>
      <div className="bg-white_A700 flex flex-col items-center justify-start mx-auto pb-[133px] md:pr-10 sm:pr-5 pr-[133px] shadow-bs6 w-full">
        <div className="flex flex-row font-sfprotext items-start justify-start p-[11px] w-[46%] md:w-full">
          <Text
            className="font-semibold ml-[21px] mt-1 text-black_900 text-center tracking-[-0.28px]"
            variant="body9"
          >
            9:41
          </Text>
          <Img
            src="images/img_signal.svg"
            className="h-2.5 ml-[249px] mt-1.5"
            alt="signal"
          />
          <Img
            src="images/img_signal_black_900.svg"
            className="h-2.5 ml-[5px] mt-[5px]"
            alt="signal_One"
          />
          <Img
            src="images/img_videocamera.svg"
            className="h-[11px] ml-[5px] mt-[5px]"
            alt="videocamera"
          />
        </div>
        <div className="font-myriadpro h-[145px] md:h-[73px] relative w-[51%] sm:w-full">
          <Text
            className="absolute bottom-[5%] right-[0] text-center text-white_A700"
            as="h1"
            variant="h1"
          >
            MyLoxam
          </Text>
          <div className="absolute h-[145px] md:h-[73px] inset-y-[0] left-[0] my-auto w-[90%] sm:w-full">
            <div className="flex flex-col m-auto w-full">
              <div className="h-[72px] mx-auto w-full">
                <div className="bg-white_A700 h-[72px] my-auto w-[41%]"></div>
                <div className="absolute bg-gray_50 flex flex-col h-full inset-[0] items-center justify-center m-auto p-[11px] rounded-[10px] shadow-bs5 w-full">
                  <div className="flex flex-row gap-2 items-start justify-center mt-[5px] w-[54%] md:w-full">
                    <Img
                      src="images/img_1280pxloxamlogo.png"
                      className="h-[35px] md:h-auto object-cover w-[21%]"
                      alt="1280pxloxamlogo"
                    />
                    <Text className="mt-0.5 text-red_A700" as="h2" variant="h2">
                      MyLoxam
                    </Text>
                  </div>
                </div>
              </div>
              <div className="bg-gray_50 flex flex-row items-center justify-between mt-[-0.33px] p-[19px] rounded-[10px] shadow-bs5 w-[96%] z-[1]">
                <Img
                  src="images/img_menu.svg"
                  className="h-[17px] ml-1.5"
                  alt="menu"
                />
                <div className="border border-black_900 border-solid flex flex-col items-end justify-start mr-[43px] p-1.5 rounded-[3px]">
                  <Img
                    src="images/img_search.svg"
                    className="h-[19px] mr-[7px] w-[19px]"
                    alt="search"
                  />
                </div>
              </div>
            </div>
            <Img
              src="images/img_cart.svg"
              className="absolute bottom-[17%] h-[25px] right-[1%]"
              alt="cart"
            />
          </div>
        </div>
        <Text
          className="font-myriadpro leading-[20.00px] mt-[9px] text-black_900 w-[42%] sm:w-full"
          variant="body11"
        >
          Accueil / Elévation et Travail en hauteur /Plate forme élévatrice /
          Nacelle ciseau / Nacelle électrique / Panier
        </Text>
        <div className="font-myriadpro h-[39px] md:h-[47px] mt-2 relative w-[42%]">
          <Line className="absolute bg-red_A700 bottom-[38%] h-[3px] inset-x-[0] mx-auto w-full" />
          <div className="absolute flex flex-row h-full inset-y-[0] items-center justify-start my-auto right-[1%] w-[95%]">
            <Button
              className="cursor-pointer font-bold h-[38px] leading-[normal] rounded-[50%] sm:text-[16.46px] md:text-[18.46px] text-[20.46px] text-center text-red_A700 w-[38px]"
              size="sm"
              variant="OutlineRedA700"
            >
              01
            </Button>
            <Button
              className="cursor-pointer font-normal h-[38px] leading-[normal] ml-[33px] rounded-[50%] sm:text-[16.46px] md:text-[18.46px] text-[20.46px] text-center text-red_A700 w-[38px]"
              size="sm"
              variant="OutlineRedA700_1"
            >
              02
            </Button>
            <Button
              className="cursor-pointer font-normal h-[38px] leading-[normal] ml-[77px] rounded-[50%] sm:text-[16.46px] md:text-[18.46px] text-[20.46px] text-center text-red_A700 w-[38px]"
              size="sm"
              variant="OutlineRedA700_1"
            >
              03
            </Button>
            <Text
              className="bg-white_A700 border border-red_A700 border-solid h-[38px] justify-center ml-[74px] pl-[13px] pr-1 py-1.5 rounded-[50%] text-center text-red_A700 w-[38px]"
              as="h6"
              variant="h6"
            >
              04
            </Text>
          </div>
        </div>
        <Text
          className="font-myriadpro mt-[9px] text-black_900"
          as="h4"
          variant="h4"
        >
          Sélectionnez vos dates :
        </Text>
        <div className="bg-gray_50 flex flex-col font-myriadpro items-center justify-start mt-[17px] p-[11px] md:px-5 rounded-[9px] shadow-bs7 w-[42%] md:w-full">
          <div className="flex flex-col gap-[9px] items-center justify-start mb-[3px] w-[94%] md:w-full">
            <div className="flex flex-row items-center justify-between w-[77%] md:w-full">
              <Img
                src="images/img_arrowleft.svg"
                className="h-6 w-[25px]"
                alt="arrowleft"
              />
              <Button
                className="cursor-pointer font-normal leading-[normal] min-w-[99px] text-base text-black_900 text-center"
                shape="RoundedBorder5"
                size="sm"
                variant="FillGray40001"
              >
                Mai 2023
              </Button>
              <Img
                src="images/img_arrowright.svg"
                className="h-6 w-[25px]"
                alt="arrowright"
              />
            </div>
            <div className="flex flex-col font-inter gap-[18px] items-start justify-start w-full">
              <div className="h-[197px] md:h-[220px] relative w-full">
                <div className="h-[197px] md:h-[220px] m-auto w-full">
                  <div className="h-[197px] md:h-[220px] m-auto w-full">
                    <div className="absolute h-[196px] md:h-[220px] inset-[0] justify-center m-auto w-full">
                      <div className="absolute flex flex-col h-max inset-y-[0] items-center justify-start left-[3%] my-auto w-[51%]">
                        <List
                          className="sm:flex-col flex-row gap-[25px] grid grid-cols-4 justify-center w-full"
                          orientation="horizontal"
                        >
                          <div className="flex flex-col gap-5 items-center justify-start sm:ml-[0] w-auto">
                            <Text
                              className="font-normal text-gray_600_01 w-[9px]"
                              variant="body6"
                            >
                              L
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01 w-1.5"
                              variant="body6"
                            >
                              1
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01 w-2.5"
                              variant="body6"
                            >
                              8
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01 w-[18px]"
                              variant="body6"
                            >
                              15
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01"
                              variant="body6"
                            >
                              22
                            </Text>
                            <Text
                              className="font-normal text-black_900"
                              variant="body6"
                            >
                              29
                            </Text>
                          </div>
                          <div className="flex flex-col gap-5 items-center justify-start sm:ml-[0] w-auto">
                            <Text
                              className="font-normal text-gray_600_01 w-3"
                              variant="body6"
                            >
                              M
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01 w-2.5"
                              variant="body6"
                            >
                              2
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01 w-2.5"
                              variant="body6"
                            >
                              9
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01 w-[18px]"
                              variant="body6"
                            >
                              16
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01"
                              variant="body6"
                            >
                              23
                            </Text>
                            <Text
                              className="font-normal text-black_900"
                              variant="body6"
                            >
                              30
                            </Text>
                          </div>
                          <div className="flex flex-col gap-5 items-center justify-center sm:ml-[0] w-auto">
                            <Text
                              className="font-normal text-gray_600_01 w-3"
                              variant="body6"
                            >
                              M
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01 w-2.5"
                              variant="body6"
                            >
                              3
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01 w-[18px]"
                              variant="body6"
                            >
                              10
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01 w-4"
                              variant="body6"
                            >
                              17
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01"
                              variant="body6"
                            >
                              24
                            </Text>
                            <Text
                              className="font-normal text-black_900 w-4"
                              variant="body6"
                            >
                              31
                            </Text>
                          </div>
                          <div className="flex flex-col gap-5 items-center justify-center sm:ml-[0] w-auto">
                            <Text
                              className="font-normal text-gray_600_01 w-2"
                              variant="body6"
                            >
                              J
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01 w-2.5"
                              variant="body6"
                            >
                              4
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01 w-[13px]"
                              variant="body6"
                            >
                              11
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01 w-[18px]"
                              variant="body6"
                            >
                              18
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01"
                              variant="body6"
                            >
                              25
                            </Text>
                            <Text
                              className="font-normal text-gray_600_01 w-1.5"
                              variant="body6"
                            >
                              1
                            </Text>
                          </div>
                        </List>
                      </div>
                      <div className="absolute bg-blue_gray_100_99 bottom-[17%] h-[27px] right-[0] rounded-bl-[13px] rounded-tl-[13px] w-2/5"></div>
                      <div className="absolute bg-blue_gray_100_99 bottom-[0] h-[27px] inset-x-[0] mx-auto rotate-[180deg] rounded-bl-[13px] rounded-tl-[13px] w-full"></div>
                    </div>
                    <div className="absolute bg-red_400_82 bottom-[0] h-[29px] right-[0] rounded-[14px] w-[29px]"></div>
                  </div>
                  <div className="absolute bg-red_400_82 bottom-[18%] h-[29px] right-[30%] rounded-[14px] w-[29px]"></div>
                </div>
                <div className="absolute flex flex-col gap-5 h-max inset-y-[0] items-center justify-center my-auto right-[31%] w-auto">
                  <Text
                    className="font-normal text-gray_600_01 w-3"
                    variant="body6"
                  >
                    V
                  </Text>
                  <Text
                    className="font-normal text-gray_600_01 w-2.5"
                    variant="body6"
                  >
                    5
                  </Text>
                  <Text
                    className="font-normal text-gray_600_01 w-[18px]"
                    variant="body6"
                  >
                    12
                  </Text>
                  <Text
                    className="font-normal text-gray_600_01 w-[18px]"
                    variant="body6"
                  >
                    19
                  </Text>
                  <Text className="font-normal text-black_900" variant="body6">
                    26
                  </Text>
                  <Text
                    className="font-normal text-gray_600_01 w-2.5"
                    variant="body6"
                  >
                    2
                  </Text>
                </div>
                <div className="absolute flex flex-col gap-5 h-max inset-y-[0] items-center justify-center my-auto right-[16%] w-auto">
                  <Text
                    className="font-normal text-gray_600_01 w-2.5"
                    variant="body6"
                  >
                    S
                  </Text>
                  <Text
                    className="font-normal text-gray_600_01 w-2.5"
                    variant="body6"
                  >
                    6
                  </Text>
                  <Text
                    className="font-normal text-gray_600_01 w-[18px]"
                    variant="body6"
                  >
                    13
                  </Text>
                  <Text
                    className="font-normal text-gray_600_01"
                    variant="body6"
                  >
                    20
                  </Text>
                  <Text
                    className="font-normal text-black_900 w-[18px]"
                    variant="body6"
                  >
                    27
                  </Text>
                  <Text
                    className="font-normal text-gray_600_01 w-2.5"
                    variant="body6"
                  >
                    3
                  </Text>
                </div>
                <div className="absolute flex flex-col gap-5 h-max inset-y-[0] items-center justify-center my-auto right-[2%] w-auto">
                  <Text
                    className="font-normal text-gray_600_01 w-3"
                    variant="body6"
                  >
                    D
                  </Text>
                  <Text
                    className="font-normal text-gray_600_01 w-2.5"
                    variant="body6"
                  >
                    7
                  </Text>
                  <Text
                    className="font-normal text-gray_600_01 w-[18px]"
                    variant="body6"
                  >
                    14
                  </Text>
                  <Text
                    className="font-normal text-gray_600_01 w-4"
                    variant="body6"
                  >
                    21
                  </Text>
                  <Text className="font-normal text-black_900" variant="body6">
                    28
                  </Text>
                  <Text
                    className="font-normal text-gray_600_01 w-2.5"
                    variant="body6"
                  >
                    4
                  </Text>
                </div>
              </div>
              <div className="flex flex-row font-myriadpro items-start justify-start w-[93%] md:w-full">
                <div className="bg-red_400_82 h-3.5 mb-[3px] rounded-[50%] w-3.5"></div>
                <Text
                  className="font-normal ml-1.5 text-black_900"
                  variant="body9"
                >
                  Date indisponible
                </Text>
                <div className="bg-red_A700 h-3.5 mb-[3px] ml-[54px] rounded-[50%] w-3.5"></div>
                <Text
                  className="font-normal ml-[7px] text-black_900"
                  variant="body9"
                >
                  Date disponible
                </Text>
              </div>
            </div>
          </div>
        </div>
        <Text
          className="font-myriadpro mt-[15px] text-black_900"
          as="h4"
          variant="h4"
        >
          Les produits à la location :
        </Text>
        <div className="font-arial md:h-[366px] h-[376px] mt-3.5 pb-[22px] relative w-[44%] sm:w-full">
          <div className="absolute bg-white_A700 flex flex-col inset-x-[0] items-center justify-start mx-auto pr-[7px] py-[7px] rounded shadow-bs8 top-[0] w-[97%]">
            <div className="flex flex-col justify-start mb-3.5 mt-[42px] w-full">
              <div className="flex flex-row items-start justify-evenly mr-[5px] w-[99%] md:w-full">
                <Img
                  src="images/img_image14.png"
                  className="h-[173px] md:h-auto object-cover w-[29%]"
                  alt="imageFourteen"
                />
                <div className="flex flex-col items-start justify-start mt-2.5">
                  <Text className="text-black_900" as="h4" variant="h4">
                    Nacelle électrique
                  </Text>
                  <Text
                    className="font-normal mt-[9px] text-black_900"
                    variant="body9"
                  >
                    <span className="text-black_900 text-sm font-arial text-left">
                      Poids (kg) :{" "}
                    </span>
                    <span className="text-black_900 text-sm font-arial text-left font-bold">
                      600
                    </span>
                  </Text>
                  <Text
                    className="font-normal mt-[7px] text-black_900"
                    variant="body9"
                  >
                    <span className="text-black_900 text-sm font-arial text-left">
                      Dimensions (L x l x h) :{" "}
                    </span>
                    <span className="text-black_900 text-sm font-arial text-left font-bold">
                      494 x 230 x 230
                    </span>
                  </Text>
                </div>
              </div>
              <div className="border-2 border-red_400 border-solid flex flex-row items-start justify-start md:ml-[0] ml-[15px] mt-[13px] p-1 rounded-[5px] w-[16%] md:w-full">
                <Text
                  className="font-bold ml-[7px] text-gray_600"
                  variant="body1"
                >
                  1
                </Text>
                <Img
                  src="images/img_arrow2.svg"
                  className="h-px ml-[15px] mt-[17px] w-px"
                  alt="arrowTwo"
                />
                <Img
                  src="images/img_arrow3.svg"
                  className="h-px mt-1 w-px"
                  alt="arrowThree"
                />
              </div>
              <div className="flex flex-row font-myriadpro gap-[19px] items-center justify-between ml-1.5 md:ml-[0] mt-[21px] w-[99%] md:w-full">
                <IPhone14ProFiftyEightButtonprimaire className="bg-red_A700 font-bold h-[43px] justify-center md:px-10 sm:px-5 px-[71px] py-3.5 rounded-[5px] text-center text-lg text-white_A700 w-[164px]" />
                <IPhone14ProFiftyEightButtonprimaire className="bg-red_A700 font-bold h-[43px] justify-center md:px-10 sm:px-5 px-[71px] py-3.5 rounded-[5px] text-center text-lg text-white_A700 w-[164px]" />
              </div>
            </div>
          </div>
          <Text
            className="absolute font-bold right-[0] text-center text-gray_600 top-[5%]"
            variant="body6"
          >
            <span className="text-gray_600 text-base font-myriadpro">
              Location du{" "}
            </span>
            <span className="text-red_400 text-base font-myriadpro">
              05/06 au 25/06
            </span>
          </Text>
          <Text
            className="absolute bottom-[23%] right-[3%] text-black_900"
            variant="body4"
          >
            8036,40 €
          </Text>
        </div>
      </div>
    </>
  );
};

export default IPhone14ProFiftyEightPage;
