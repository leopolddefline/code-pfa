import React from "react";

import { Button, Img, Input, Line, List, Radio, Text } from "components";
import IPhone14ProFiftyNineClick from "components/IPhone14ProFiftyNineClick";

const IPhone14ProSixtyPage = () => {
  return (
    <>
      <div className="bg-white_A700 flex flex-col items-center justify-start mx-auto pb-[63px] md:pr-10 sm:pr-5 pr-[63px] shadow-bs6 w-full">
        <div className="flex flex-row font-sfprotext items-start justify-start p-[11px] w-[42%] md:w-full">
          <Text
            className="font-semibold ml-[21px] mt-1 text-black_900 text-center tracking-[-0.28px]"
            variant="body9"
          >
            9:41
          </Text>
          <Img
            src="images/img_signal.svg"
            className="h-2.5 ml-[249px] mt-1.5"
            alt="signal"
          />
          <Img
            src="images/img_signal_black_900.svg"
            className="h-2.5 ml-[5px] mt-[5px]"
            alt="signal_One"
          />
          <Img
            src="images/img_videocamera.svg"
            className="h-[11px] ml-[5px] mt-[5px]"
            alt="videocamera"
          />
        </div>
        <div className="font-myriadpro h-[145px] relative w-[47%] sm:w-full">
          <Text
            className="absolute bottom-[5%] right-[0] text-center text-white_A700"
            as="h1"
            variant="h1"
          >
            MyLoxam
          </Text>
          <div className="absolute flex flex-col h-full inset-y-[0] items-center justify-start left-[0] my-auto w-[91%]">
            <div className="h-[72px] relative w-full">
              <div className="bg-white_A700 h-[72px] my-auto w-[42%]"></div>
              <div className="absolute bg-gray_50 flex flex-col h-full inset-[0] items-center justify-center m-auto p-[11px] rounded-[10px] shadow-bs5 w-full">
                <div className="flex flex-row gap-2 items-start justify-center mt-[5px] w-[54%] md:w-full">
                  <Img
                    src="images/img_1280pxloxamlogo.png"
                    className="h-[35px] md:h-auto object-cover w-[21%]"
                    alt="1280pxloxamlogo"
                  />
                  <Text className="mt-0.5 text-red_A700" as="h2" variant="h2">
                    MyLoxam
                  </Text>
                </div>
              </div>
            </div>
            <div className="bg-gray_50 flex flex-row items-center justify-between pl-[19px] py-[19px] rounded-[10px] shadow-bs5 w-full">
              <Img
                src="images/img_menu.svg"
                className="h-[17px] ml-[7px]"
                alt="menu"
              />
              <div className="border border-black_900 border-solid flex flex-col items-end justify-start p-1.5 rounded-[3px]">
                <Img
                  src="images/img_search.svg"
                  className="h-[19px] mr-[9px] w-[19px]"
                  alt="search"
                />
              </div>
              <Img
                src="images/img_cart.svg"
                className="h-[25px] w-6"
                alt="cart"
              />
            </div>
          </div>
        </div>
        <Text
          className="font-myriadpro leading-[20.00px] mt-[9px] text-black_900 w-[39%] sm:w-full"
          variant="body11"
        >
          Accueil / Elévation et Travail en hauteur /Plate forme élévatrice /
          Nacelle ciseau / Nacelle électrique / Panier
        </Text>
        <div className="font-myriadpro h-[41px] md:h-[49px] mt-2 relative w-[39%]">
          <Line className="absolute bg-red_A700 bottom-[41%] h-[3px] inset-x-[0] mx-auto w-full" />
          <div className="absolute flex flex-row h-full inset-[0] items-start justify-center m-auto w-[94%]">
            <Button
              className="cursor-pointer font-normal h-[38px] leading-[normal] mb-0.5 rounded-[50%] sm:text-[16.46px] md:text-[18.46px] text-[20.46px] text-center text-red_A700 w-[38px]"
              size="sm"
              variant="OutlineRedA700_1"
            >
              01
            </Button>
            <Button
              className="cursor-pointer font-bold h-[38px] leading-[normal] mb-0.5 ml-[38px] rounded-[50%] sm:text-[16.46px] md:text-[18.46px] text-[20.46px] text-center text-red_A700 w-[38px]"
              size="sm"
              variant="OutlineRedA700"
            >
              02
            </Button>
            <Button
              className="cursor-pointer font-normal h-[38px] leading-[normal] mb-0.5 ml-[75px] rounded-[50%] sm:text-[16.46px] md:text-[18.46px] text-[20.46px] text-center text-red_A700 w-[38px]"
              size="sm"
              variant="OutlineRedA700_1"
            >
              03
            </Button>
            <Button
              className="cursor-pointer font-normal h-[38px] leading-[normal] ml-[67px] mt-0.5 rounded-[50%] sm:text-[16.46px] md:text-[18.46px] text-[20.46px] text-center text-red_A700 w-[38px]"
              size="sm"
              variant="OutlineRedA700_1"
            >
              04
            </Button>
          </div>
        </div>
        <Text
          className="font-myriadpro mt-2 text-black_900 w-[35%] sm:w-full"
          as="h4"
          variant="h4"
        >
          Choisissez votre mode de retrait :
        </Text>
        <div className="font-myriadpro md:h-[120px] h-[588px] mt-[22px] relative w-[39%]">
          <div className="absolute bg-white_A700 bottom-[0] flex flex-col gap-[17px] items-center justify-start left-[0] p-1.5 rounded shadow-bs4 w-[96%]">
            <Input
              wrapClassName="flex md:h-auto mt-1.5 w-[217px]"
              className="font-bold leading-[normal] p-0 placeholder:text-red_A400 text-left text-red_A400 text-xl w-full"
              name="buttonsecondary"
              placeholder="Paris 14éme"
              suffix={
                <div className="h-[18px] mt-[3px] mb-px ml-[22px] w-[18px] bg-red_A700">
                  <Img
                    src="images/img_frame625954.svg"
                    className="my-auto"
                    alt="Vector"
                  />
                </div>
              }
              shape="RoundedBorder5"
              size="md"
              variant="OutlineRedA400"
            ></Input>
            <div className="flex flex-col font-arial items-center justify-start mb-[7px] w-full">
              <List
                className="flex-col gap-3.5 grid items-center w-full"
                orientation="vertical"
              >
                <div className="border border-black_900 border-solid flex flex-1 flex-col items-center justify-start my-0 p-[11px] rounded-[5px] w-full">
                  <div className="flex flex-row items-start justify-between my-[3px] w-[99%] md:w-full">
                    <div className="flex flex-col items-start justify-start w-[79%]">
                      <Text
                        className="font-bold ml-0.5 md:ml-[0] text-black_900"
                        variant="body13"
                      >
                        LOXAM City Paris 14ème Porte D’Orléans
                      </Text>
                      <div className="flex flex-row items-start justify-between mt-[7px] w-full">
                        <Text
                          className="font-normal mt-1 text-black_900"
                          variant="body14"
                        >
                          1,5 km
                        </Text>
                        <Line className="bg-black_900 h-2.5 mb-[9px] mt-1.5 rotate-[-90deg] w-px" />
                        <Text
                          className="font-normal text-black_900"
                          variant="body13"
                        >
                          132 avenue du Général Leclerc, 75014 Paris
                        </Text>
                      </div>
                      <div className="flex flex-row gap-[13px] items-start justify-start mt-1 w-[74%] md:w-full">
                        <Text
                          className="font-bold text-red_400"
                          variant="body14"
                        >
                          Ouvert
                        </Text>
                        <Text
                          className="font-normal text-black_900"
                          variant="body14"
                        >
                          aujourd’hui jusqu’à 18h00
                        </Text>
                      </div>
                    </div>
                    <IPhone14ProFiftyNineClick className="bg-gray_100_01 flex flex-col items-center justify-start mb-7 mt-3 p-[5px] rounded-[12px] shadow-bs sm:w-full" />
                  </div>
                </div>
                <div className="border border-black_900 border-solid flex flex-1 flex-col items-center justify-start my-0 p-[11px] rounded-[5px] w-full">
                  <div className="flex flex-col items-start justify-start my-[3px] w-full">
                    <Text
                      className="font-bold ml-0.5 md:ml-[0] text-black_900"
                      variant="body14"
                    >
                      Loxam City Grenelle
                    </Text>
                    <div className="flex flex-row items-start justify-between mt-1 w-full">
                      <Text
                        className="font-normal mt-[7px] text-black_900"
                        variant="body14"
                      >
                        1,5 km
                      </Text>
                      <Line className="bg-black_900 h-2.5 mb-0.5 mt-[9px] rotate-[-90deg] w-px" />
                      <Radio
                        value="96boulevarddeGrenelle75015Paris"
                        className="font-normal leading-[normal] sm:pr-5 text-[11.03px] text-black_900 text-left"
                        inputClassName="h-[22px] mr-[5px] w-[22px]"
                        checked={true}
                        name="boulevardde"
                        label="96 boulevard de Grenelle 75015 Paris"
                        id="96boulevarddeGrenelle75015Paris"
                        shape="CircleBorder11"
                        size="md"
                        variant="OutlineBlack9003f"
                      ></Radio>
                    </div>
                    <div className="flex flex-row gap-[13px] items-start justify-start mt-[11px] w-[57%] md:w-full">
                      <Text className="font-bold text-red_400" variant="body14">
                        Ouvert
                      </Text>
                      <Text
                        className="font-normal text-black_900"
                        variant="body14"
                      >
                        aujourd’hui jusqu’à 18h00
                      </Text>
                    </div>
                  </div>
                </div>
                <div className="border border-black_900 border-solid flex flex-1 flex-col items-center justify-start my-0 p-[9px] rounded-[5px] w-full">
                  <div className="flex flex-col items-start justify-start my-[5px] w-full">
                    <Text
                      className="font-bold ml-0.5 md:ml-[0] text-black_900"
                      variant="body14"
                    >
                      Loxam City Montparnasse
                    </Text>
                    <div className="flex flex-row items-start justify-between w-full">
                      <Text
                        className="font-normal mt-[11px] text-black_900"
                        variant="body14"
                      >
                        1,5 km
                      </Text>
                      <Line className="bg-black_900 h-2.5 mt-[13px] rotate-[-90deg] w-px" />
                      <Radio
                        value="50BoulevardPasteur75015Paris"
                        className="font-normal leading-[normal] sm:pr-5 text-[11.03px] text-black_900 text-left"
                        inputClassName="h-6 mr-[5px] w-6"
                        checked={true}
                        name="boulevardpastOne"
                        label="50 Boulevard Pasteur 75015 Paris"
                        id="50BoulevardPasteur75015Paris"
                        shape="CircleBorder11"
                        size="md"
                        variant="OutlineBlack9003f_1"
                      ></Radio>
                    </div>
                    <div className="flex flex-row gap-[13px] items-start justify-start mt-3 w-[57%] md:w-full">
                      <Text className="font-bold text-red_400" variant="body14">
                        Ouvert
                      </Text>
                      <Text
                        className="font-normal text-black_900"
                        variant="body14"
                      >
                        aujourd’hui jusqu’à 18h00
                      </Text>
                    </div>
                  </div>
                </div>
                <div className="border border-black_900 border-solid flex flex-1 flex-col items-center justify-start my-0 p-1 rounded-[5px] w-full">
                  <div className="flex flex-col items-start justify-start my-2.5 w-[98%] md:w-full">
                    <Text
                      className="font-bold ml-0.5 md:ml-[0] text-black_900"
                      variant="body14"
                    >
                      Loxam City Porte de Brancion
                    </Text>
                    <div className="flex flex-row items-start justify-between mt-[7px] w-full">
                      <Text
                        className="font-normal mt-1 text-black_900"
                        variant="body14"
                      >
                        1,5 km
                      </Text>
                      <Line className="bg-black_900 h-2.5 mb-3 mt-1.5 rotate-[-90deg] w-px" />
                      <Radio
                        value="3avenuedelaPorteBrancion75015Paris"
                        className="font-normal leading-[normal] sm:pr-5 text-[11.03px] text-black_900 text-left"
                        inputClassName="h-6 mr-[5px] w-6"
                        checked={true}
                        name="avenuedelaportOne"
                        label="3 avenue de la Porte Brancion 75015 Paris"
                        id="3avenuedelaPorteBrancion75015Paris"
                        shape="CircleBorder11"
                        size="sm"
                        variant="OutlineBlack9003f_1"
                      ></Radio>
                    </div>
                    <div className="flex flex-row gap-[13px] items-start justify-start w-[56%] md:w-full">
                      <Text className="font-bold text-red_400" variant="body14">
                        Ouvert
                      </Text>
                      <Text
                        className="font-normal text-black_900"
                        variant="body14"
                      >
                        aujourd’hui jusqu’à 18h00
                      </Text>
                    </div>
                  </div>
                </div>
              </List>
            </div>
          </div>
          <div className="absolute bg-white_A700 flex flex-col inset-x-[0] items-start justify-start mx-auto p-3 rounded shadow-bs4 top-[0] w-full">
            <div className="flex flex-row gap-2.5 items-center justify-start w-[95%] md:w-full">
              <div className="bg-white_A700 flex flex-col h-[21px] items-center justify-end my-[11px] p-[5px] rounded-[10px] shadow-bs4 w-[21px]">
                <div className="bg-red_400 border border-red_400 border-solid h-2.5 rounded-[50%] w-2.5"></div>
              </div>
              <div className="flex flex-col items-start justify-start w-[91%]">
                <Text className="text-black_900" variant="body3">
                  Click & collect en agence Loxam
                </Text>
                <Line className="bg-black_900_7f h-px mt-0.5 w-full" />
                <Text className="text-gray_600_01" variant="body8">
                  Gratuit
                </Text>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-white_A700 flex flex-col font-myriadpro items-center justify-start mt-[21px] p-[9px] md:px-5 rounded shadow-bs4 w-[39%] md:w-full">
          <div className="flex flex-row gap-[15px] items-center justify-between mb-[5px] w-[95%] md:w-full">
            <IPhone14ProFiftyNineClick className="bg-white_A700 flex flex-col h-[21px] items-center justify-end mb-[9px] mt-[15px] p-[5px] rounded-[10px] shadow-bs4 w-[21px] sm:w-full" />
            <div className="flex flex-col items-start justify-start w-[89%]">
              <Text className="text-black_900" variant="body3">
                Livraison
              </Text>
              <Line className="bg-black_900_7f h-px mt-1 w-full" />
              <Text className="text-gray_600_01" variant="body8">
                250 €
              </Text>
            </div>
          </div>
        </div>
        <Button
          className="cursor-pointer font-bold font-myriadpro leading-[normal] mt-[29px] text-center text-red_A400 text-xl w-[170px]"
          shape="RoundedBorder5"
          size="lg"
          variant="OutlineRedA400"
        >
          Suivant
        </Button>
      </div>
    </>
  );
};

export default IPhone14ProSixtyPage;
