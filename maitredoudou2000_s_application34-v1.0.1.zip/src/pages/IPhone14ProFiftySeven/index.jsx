import React from "react";

import { Button, Img, Input, SelectBox, Text } from "components";
import IPhone14ProFiftySixColumnFive from "components/IPhone14ProFiftySixColumnFive";

const hs18EOptionsList = [
  { label: "Option1", value: "option1" },
  { label: "Option2", value: "option2" },
  { label: "Option3", value: "option3" },
];
const hs18EOptionsList1 = [
  { label: "Option1", value: "option1" },
  { label: "Option2", value: "option2" },
  { label: "Option3", value: "option3" },
];
const hs18EOptionsList2 = [
  { label: "Option1", value: "option1" },
  { label: "Option2", value: "option2" },
  { label: "Option3", value: "option3" },
];

const IPhone14ProFiftySevenPage = () => {
  return (
    <>
      <div className="bg-white_A700 flex flex-col items-start justify-start mx-auto shadow-bs6 w-full">
        <div className="flex flex-col justify-start md:px-5 w-[82%] md:w-full">
          <div className="flex flex-row font-sfprotext items-start justify-start p-[11px] w-[49%] md:w-full">
            <Text
              className="font-semibold ml-[21px] mt-1 text-black_900 text-center tracking-[-0.28px]"
              variant="body9"
            >
              9:41
            </Text>
            <Img
              src="images/img_signal.svg"
              className="h-2.5 ml-[249px] mt-1.5"
              alt="signal"
            />
            <Img
              src="images/img_signal_black_900.svg"
              className="h-2.5 ml-[5px] mt-[5px]"
              alt="signal_One"
            />
            <Img
              src="images/img_videocamera.svg"
              className="h-[11px] ml-[5px] mt-[5px]"
              alt="videocamera"
            />
          </div>
          <div className="font-myriadpro h-[145px] relative w-[54%] sm:w-full">
            <Text
              className="absolute bottom-[5%] right-[0] text-center text-white_A700"
              as="h1"
              variant="h1"
            >
              MyLoxam
            </Text>
            <div className="absolute flex flex-col h-full inset-y-[0] items-start justify-start left-[0] my-auto w-[90%]">
              <div className="h-[72px] relative w-full">
                <div className="bg-white_A700 h-[72px] my-auto w-2/5"></div>
                <div className="absolute bg-gray_50 flex flex-col h-full inset-[0] items-center justify-center m-auto p-[11px] rounded-[10px] shadow-bs5 w-full">
                  <div className="flex flex-row gap-2 items-start justify-center mt-[5px] w-[54%] md:w-full">
                    <Img
                      src="images/img_1280pxloxamlogo.png"
                      className="h-[35px] md:h-auto object-cover w-[21%]"
                      alt="1280pxloxamlogo"
                    />
                    <Text className="mt-0.5 text-red_A700" as="h2" variant="h2">
                      MyLoxam
                    </Text>
                  </div>
                </div>
              </div>
              <div className="bg-gray_50 flex flex-row items-center justify-start pl-[19px] py-[19px] rounded-[10px] shadow-bs5 w-[96%] md:w-full">
                <Img
                  src="images/img_menu.svg"
                  className="h-[17px] ml-[5px]"
                  alt="menu"
                />
                <div className="border border-black_900 border-solid flex flex-col items-end justify-start ml-[61px] p-1.5 rounded-[3px] w-[54%]">
                  <Img
                    src="images/img_search.svg"
                    className="h-[19px] w-[19px]"
                    alt="search"
                  />
                </div>
                <Img
                  src="images/img_cart.svg"
                  className="h-[25px] ml-[49px]"
                  alt="cart"
                />
              </div>
            </div>
          </div>
          <Text
            className="font-myriadpro leading-[20.00px] ml-4 md:ml-[0] mt-[9px] text-black_900 w-[45%] sm:w-full"
            variant="body11"
          >
            Accueil / Elévation et Travail en hauteur /Plate forme élévatrice /
            Nacelle ciseau / Nacelle électrique
          </Text>
          <Img
            src="images/img_rectangle381.png"
            className="h-[273px] sm:h-auto ml-4 md:ml-[0] mt-[17px] object-cover rounded-[5px] w-[45%] md:w-full"
            alt="rectangle381"
          />
          <Text
            className="font-myriadpro ml-4 md:ml-[0] mt-[19px] text-black_900"
            as="h4"
            variant="h4"
          >
            Nacelle électrique
          </Text>
          <Text
            className="font-myriadpro ml-4 md:ml-[0] text-black_900"
            variant="body2"
          >
            Référence : HS18 E
          </Text>
          <Text
            className="font-myriadpro leading-[20.00px] md:ml-[0] ml-[15px] mt-1.5 text-black_900 w-[45%] sm:w-full"
            variant="body7"
          >
            Cette plateforme ciseau électrique a été conçue pour répondre aux
            conditions tout terrain les plus rudes. Grâce à ses 4 roues motrices
            permanentes, son blocage de différentiel et son système de
            stabilisation automatique, elle s’affranchira de toutes les
            situations. Elle offre en outre la meilleure capacité de levage du
            segment jusqu’à 750 kg et une plateforme extra large de 7,4 m de
            long pour embarquer un maximum de matériel.
          </Text>
          <Text
            className="font-bold font-myriadpro ml-4 md:ml-[0] mt-[18px] text-black_900"
            variant="body5"
          >
            A PARTIR DE :
          </Text>
          <div className="flex flex-row font-myriadpro gap-[159px] items-start justify-start ml-4 md:ml-[0] mt-0.5 w-[41%] md:w-full">
            <Text className="mt-[3px] text-black_900" as="h3" variant="h3">
              535,76 €
            </Text>
            <div className="md:h-6 h-8 relative w-[13%]">
              <Text
                className="absolute font-light left-[0] text-black_900 top-[0]"
                variant="body1"
              >
                *
              </Text>
              <Text
                className="absolute bottom-[0] font-light inset-x-[0] mx-auto text-black_900 w-max"
                variant="body12"
              >
                TTC/jour
              </Text>
            </div>
          </div>
          <Button
            className="cursor-pointer font-bold font-myriadpro h-[43px] leading-[normal] ml-4 md:ml-[0] mr-[441px] mt-2.5 text-center text-lg text-white_A700 w-[361px]"
            shape="RoundedBorder5"
            size="md"
            variant="FillRedA700"
          >
            Etablir un devis
          </Button>
          <div className="flex md:flex-col flex-row font-myriadpro md:gap-10 items-center justify-between md:ml-[0] ml-[17px] mt-7 w-[98%] md:w-full">
            <Input
              wrapClassName="md:w-full"
              className="font-bold leading-[normal] p-0 placeholder:text-gray_100_01 text-[13.67px] text-gray_100_01 text-left w-full"
              name="groupTwentyFive"
              placeholder="Caractéristiques"
              size="md"
              variant="FillRedA700"
            ></Input>
            <SelectBox
              className="font-bold leading-[normal] text-[13.67px] text-gray_100_01 text-left w-[31%] md:w-full"
              placeholderClassName="text-gray_100_01"
              indicator={
                <Img
                  src="images/img_arrowdown.svg"
                  className="h-[25px] mr-[0] w-6"
                  alt="arrow_down"
                />
              }
              isMulti={false}
              name="groupForty"
              options={hs18EOptionsList}
              isSearchable={false}
              placeholder="HS18 E"
            />
          </div>
          <div className="flex md:flex-col flex-row font-myriadpro md:gap-10 items-center justify-between md:ml-[0] ml-[15px] mt-[17px] w-[98%] md:w-full">
            <Input
              wrapClassName="md:w-full"
              className="font-bold leading-[normal] p-0 placeholder:text-gray_100_01 text-[13.72px] text-gray_100_01 text-left w-full"
              name="groupTwentySix"
              placeholder="Applications"
              size="md"
              variant="FillRedA700"
            ></Input>
            <SelectBox
              className="font-bold leading-[normal] text-[13.67px] text-gray_100_01 text-left w-[31%] md:w-full"
              placeholderClassName="text-gray_100_01"
              indicator={
                <Img
                  src="images/img_arrowdown.svg"
                  className="h-[25px] mr-[0] w-6"
                  alt="arrow_down"
                />
              }
              isMulti={false}
              name="groupFortyTwo"
              options={hs18EOptionsList1}
              isSearchable={false}
              placeholder="HS18 E"
            />
          </div>
          <div className="flex md:flex-col flex-row font-myriadpro md:gap-10 items-center justify-between md:ml-[0] ml-[15px] mt-[17px] w-[98%] md:w-full">
            <Input
              wrapClassName="md:w-full"
              className="font-bold leading-[normal] p-0 placeholder:text-gray_100_01 text-[13.72px] text-gray_100_01 text-left w-full"
              name="groupTwentySeven"
              placeholder="Techniques"
              size="md"
              variant="FillRedA700"
            ></Input>
            <SelectBox
              className="font-bold leading-[normal] text-[13.67px] text-gray_100_01 text-left w-[31%] md:w-full"
              placeholderClassName="text-gray_100_01"
              indicator={
                <Img
                  src="images/img_arrowdown.svg"
                  className="h-[25px] mr-[0] w-6"
                  alt="arrow_down"
                />
              }
              isMulti={false}
              name="groupFortyFour"
              options={hs18EOptionsList2}
              isSearchable={false}
              placeholder="HS18 E"
            />
          </div>
          <IPhone14ProFiftySixColumnFive
            className="bg-gray_100 flex flex-col font-myriadpro items-center justify-start mr-[426px] mt-[9px] rounded-[5px] shadow-bs3 sm:w-full"
            location="Location"
            chantier="Chantier"
            facturedevis={
              <>
                Facture &<br />
                Devis
              </>
            }
            compte="Compte"
          />
        </div>
      </div>
    </>
  );
};

export default IPhone14ProFiftySevenPage;
