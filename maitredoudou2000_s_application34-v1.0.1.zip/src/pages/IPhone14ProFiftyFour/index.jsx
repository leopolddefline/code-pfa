import React from "react";

import { Button, Img, Input, Text } from "components";
import IPhone14ProFiftyFourTabbar from "components/IPhone14ProFiftyFourTabbar";

const IPhone14ProFiftyFourPage = () => {
  return (
    <>
      <div className="bg-white_A700 flex flex-col font-sfprotext items-start justify-start mx-auto pb-[185px] w-full">
        <div className="flex flex-col items-center w-full">
          <div className="flex flex-col md:px-5 relative w-full">
            <div className="flex sm:flex-col flex-row sm:gap-5 items-start justify-start mx-auto p-2.5 w-full">
              <Text
                className="font-semibold sm:ml-[0] ml-[23px] sm:mt-0 mt-[5px] text-black_900 text-center tracking-[-0.28px]"
                variant="body9"
              >
                9:41
              </Text>
              <Img
                src="images/img_signal.svg"
                className="h-2.5 sm:ml-[0] ml-[271px]"
                alt="signal"
              />
              <Img
                src="images/img_signal_black_900.svg"
                className="h-2.5 sm:ml-[0] ml-[5px]"
                alt="signal_One"
              />
              <Img
                src="images/img_videocamera.svg"
                className="h-[11px] sm:ml-[0] ml-[5px]"
                alt="videocamera"
              />
            </div>
            <IPhone14ProFiftyFourTabbar className="bg-white_A700_cc flex flex-col items-center justify-end ml-0.5 mt-[-5px] pt-2.5 w-[390px] sm:w-full z-[1]" />
          </div>
        </div>
        <div className="flex flex-col font-myriadpro md:px-5 relative w-2/5 sm:w-full">
          <div className="bg-red_A700 flex flex-col items-end justify-start mx-auto p-[29px] sm:px-5 w-full">
            <div className="flex flex-col justify-start mb-[122px] mr-[65px] w-[54%] md:w-full">
              <Img
                src="images/img_image8.png"
                className="h-[99px] md:h-auto md:ml-[0] ml-[26px] object-cover w-[100px] sm:w-full"
                alt="imageEight"
              />
              <Text
                className="text-center text-white_A700"
                as="h1"
                variant="h1"
              >
                MyLoxam
              </Text>
            </div>
          </div>
          <div className="bg-gray_50 flex flex-col items-start justify-center mt-[-122.16px] mx-auto p-5 rounded-[10px] shadow-bs5 w-[74%] z-[1]">
            <Text className="mt-[42px] text-blue_gray_900" as="h4" variant="h4">
              Connexion
            </Text>
            <Input
              wrapClassName="mt-[31px] w-full"
              className="font-normal leading-[normal] p-0 placeholder:text-blue_gray_400 text-[13px] text-blue_gray_400 text-left w-full"
              name="groupSeventeen"
              placeholder="Nom d’utilisateur"
              shape="RoundedBorder5"
              size="lg"
              variant="OutlineGray300"
            ></Input>
            <Input
              wrapClassName="flex mt-3.5 w-full"
              className="font-normal leading-[normal] p-0 placeholder:text-blue_gray_400 text-[13px] text-blue_gray_400 text-left w-full"
              name="groupSixteen"
              placeholder="Mot de passe"
              suffix={
                <div className="ml-[35px] sm:w-full sm:mx-0 w-[10%] bg-gray_500">
                  <Img src="images/img_eye.svg" className="my-auto" alt="eye" />
                </div>
              }
              shape="RoundedBorder5"
              size="sm"
              variant="OutlineGray300"
            ></Input>
            <Button
              className="cursor-pointer font-bold leading-[normal] mt-[25px] text-center text-lg text-white_A700 w-[246px]"
              shape="RoundedBorder5"
              size="lg"
              variant="FillRedA700"
            >
              Se connecter
            </Button>
            <Text
              className="font-bold mb-[111px] md:ml-[0] ml-[91px] mt-3 text-center text-red_A700 underline"
              variant="body6"
            >
              S’inscrire
            </Text>
          </div>
        </div>
      </div>
    </>
  );
};

export default IPhone14ProFiftyFourPage;
